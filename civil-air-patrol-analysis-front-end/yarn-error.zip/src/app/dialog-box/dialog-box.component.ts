import { Component, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-dialog-box',
  templateUrl: './dialog-box.component.html',
  styleUrls: ['./dialog-box.component.css']
})
export class DialogBoxComponent {

  message: String;

  constructor(public dialog: MatDialog) { }

  openDialog(message: String){
    this.message = message;
    let dialogRef = this.dialog.open(DialogBox,{
      data: { message: message },
      height: '75px',
      width: '400px'
    })
  }

}

@Component({
  selector: 'dialog-box',
  templateUrl: 'dialog-box.html',
})
export class DialogBox {

  constructor(
    public dialogRef: MatDialogRef<DialogBox>,
    @Inject(MAT_DIALOG_DATA) public data: any) { }

  onNoClick(): void {
    this.dialogRef.close();
    console.log('DIALOG BOX CLOSE');
  }

}
