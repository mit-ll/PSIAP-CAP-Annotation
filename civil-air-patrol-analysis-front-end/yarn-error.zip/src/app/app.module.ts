import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { DialogBoxComponent, DialogBox } from './dialog-box/dialog-box.component';
import { MatDialogModule } from '@angular/material';


@NgModule({
  declarations: [
    AppComponent,
    DialogBoxComponent,
    DialogBox
  ],
  imports: [
    BrowserModule,
    MatDialogModule
  ],
  entryComponents: [DialogBoxComponent, DialogBox],
  providers: [MatDialogModule],
  bootstrap: [AppComponent]
})
export class AppModule { }
