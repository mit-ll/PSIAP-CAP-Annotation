import { Component } from '@angular/core';
import { DialogBoxComponent, DialogBox } from './dialog-box/dialog-box.component';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Welcome to the Facial Comparison Application';
  test = 'dfe';
}
